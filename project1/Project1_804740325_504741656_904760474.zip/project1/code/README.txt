##############   Environment Setup - ################

All the codes and .csv files need to be in the same folder.
To import various libraries in R workspace and to load the data, run the file imports.r. This can be done by selecting the code and clicking the 'Run' button.


##############   Running the code - ##################
1. The R code files are project1part1.r, project1part2a.r, project1part2b.r, project1part2c.r, project1part3.3, project1part4.r and project1part5.r.

2. Each files contains code of their respective problems. 

3. To run specific statements. select the corresponding code and click 'Run'. 

4. For example, to plot a graph, select the corresponding line of code that plots that graph and click 'Run'. 

We have segmented the code in each file according to various subparts of the problem for ease of runnung the code.